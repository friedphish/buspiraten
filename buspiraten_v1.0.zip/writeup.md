**FOR IMMEDIATE DISSIMATION: 01/09/2019**

We, the Public Transport Pirate Association of the United Kingdom are releasing
our research on reverse engineering public transportation tickets in most major
UK cities (excl. London.)

The reason we've decided not to go down the responsible disclosure path is being
strong believers in public transportation being a common good that should be
free for everyone, and this research is our contribution to get us closer to
that end.

The initial release focuses on the Greater Manchester area, but can be easily
adapted to other transportation networks that use the corethree middleware for
their electronic tickets.

The security of the corethree apps is laughable at best, we could tell you guys
really tried, but in the end focused too much on low-tech threats (i.e. taking
a screenshot of a ticket and sending it to a friend) to be much of a challenge
to even a novice hacker/reverse engineer.
We'd especially like to thank you for including the private RSA keys to sign the
QR codes in the First Bus m-ticket app.

### Transport for Greater Manchester ###

The code is ready to use as is. Might need some adjustment to look nice on your
device, as we didn't really bother to make it "responsive". We recommend
packaging it as a simple WebView APK to make it look more "legit" rather than
just displaying it in a web browser.

[Try it out](./tfgm/dist/index.html)

### First Bus Manchester ###

Some assembly required. You need data from an existing ticket QR code, this will
get patched to include the current day as the purchase/expiration date and a
valid RSA signature. Yes, it does work with the barcode scanners.

### Downloads ###

This package includes everything you need to make yourself a nice self-hosted
version of this. The source code is included and you should also be able to
figure out how to adapt it to tickets from other ticket providers with just a
little reverse engineering.

Everything is there for somebody to package this into a nice app and put it up
on F-Droid or something. We ran out of time.

- [buspiraten_v1.0.zip](./buspiraten_v1.0.zip)
- [buspiraten_v1.0.zip.asc](./buspiraten_v1.0.zip.asc)

### Contact us ###

`buspiratenuk@protonmail.ch`

```
-----BEGIN PGP PUBLIC KEY BLOCK-----

mQENBF1sDtMBCAC7wJivy/qkFwtG4fENg47ltr9NFNxqDwJWArzdCBdMQvp+aT4a
zzqk4HhuesSN3rNsthtOimBI+umfbetXw455Dny3bMNHu7LCP0rXCz6rgbr4Hvya
YiFoXvtnd5z3CgwT3FRb0LBeqJU2iyIX1BYRB2xrywHQsmdtjwFYSwpBw0HtdvXA
+jS0Y8jnPDfZqutpcnrl0M3AF+oR1Q0sS87x78+YUGK4kNKNGHIBA7M4YDKCdyLz
LoOSWIqa8nIqejZx8AfuwOFUJZSEC7VfJAvuZ+n7R5AudcLHFYHHLKax4KsCeW4O
xay3piADHFaYbFN3DICVM06C52Dahfnx0zI1ABEBAAG0VlB1YmxpYyBUcmFuc3Bv
cnQgUGlyYXRlIEFzc29jaWF0aW9uIG9mIHRoZSBVbml0ZWQgS2luZ2RvbSA8YnVz
cGlyYXRlbnVrQHByb3Rvbm1haWwuY2g+iQFUBBMBCAA+FiEEHw/FL/mN+yyUKVi0
Dd8FkMr47RIFAl1sDtMCGwMFCQPCZwAFCwkIBwIGFQoJCAsCBBYCAwECHgECF4AA
CgkQDd8FkMr47RKFhgf/fpeleDtQWkxUD6jkN4jHGIa3zRwJbFQPsiwlZHnOxOiS
tf7eSjit1aTJz8hjdrHjUkRUxlW2vpHZCQGSgti/GIpYvbFIHCN9AKks3xIvvCNY
2jfgqFyqyrTECT6TKO6lE4qWzKn33Bvwdcxq9tAXM2frQ6v5KK79c7qyZGWk/mRx
QFaeuOeV4F+gx0e6aHHqbWR/JxmDe2d3+w6S7ZQoG0EMaR617b5ke36+W7TiA8KJ
f5sLW0by4Rskmwjuzxey2agTQaVATYphSonL1eK7QYPVycRL+1UOKOcHGPhSZmGr
uJw0DUvoadJN1I1kRqbFfKqQAi9NtOs3KBYAvjBjKbkBDQRdbA7TAQgA63XSDnEl
g65wYfiFg1CVUgslWKZ1YZP0/Vw0vyjv0TajSvxoyaaBMHY7uZfoGEb5e6r2RYJV
MegV+8JluzeA/fzObj1wEjgH+i5zYg1lWSr1A5aeS+6vZKyTinbrT38DPlKuMwCA
MIiOaTw4rDhlHqKwN0wjivtIK42mElBxnWdbLGZSGk+kdGiw5ZX1HYhFWI/egcOL
xOOBHRm6nPMZhNDUy8k3A2AtHXqdHDQNIOXdcYXGImWppnU7objNgxAIDsmmOzp5
8As8nDaD5BS/dqeu7eVYQWMiiVCjH/XgYpWQ3SACiNiB/27A1987On5A+oZm65di
0j5d0LBlt7E8cQARAQABiQE8BBgBCAAmFiEEHw/FL/mN+yyUKVi0Dd8FkMr47RIF
Al1sDtMCGwwFCQPCZwAACgkQDd8FkMr47RJgcwgApmoHlH7nEI7h76m3x2WRDR8L
3Qwb+BsmNAT3Kss0Zpec3zihstwZ9mYCEy2bQHAuQVqTeCAz/+sY0BQImUhzMfeE
P2D1tV9lVrUIgSS1p5dntJuQ5YhxFSSfSzzcokC3mjwvWqYiTfC02Tj97KuMaENY
VHrEyiPgSTxBd1aAD/uHuSZcl+hPzUqotI5r4VHvzYQGyM05hEkKMAqkVdheiY0c
wBDiBi+saJNf55E+TVUHtScvkoBYSh2PqLoxavZsTvP8YJnGDGR3If7xuqFa41zn
WFUCYYbpUgA2PqNBH0WAKkoi8++iyBvnfuV0gBt9Mh1hSajozjZDlLTWEjPFTg==
=V91z
-----END PGP PUBLIC KEY BLOCK-----
```

### People we think are cool ###

No claim of association.

- [Campaign for Free Public Transport](http://www.freepublictransport.org.uk/)
- [planka.nu](https://planka.nu/)

Buy us a Club-Mate: `34tQaxCReTm4mpHYWhJubhiMuqM4f65JUF`
