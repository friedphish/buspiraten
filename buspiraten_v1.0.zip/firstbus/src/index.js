import m from "mithril"
import barcode from "./barcode"
import words from "./words"

const root = document.getElementById("root");
const word = words();
let b = barcode().outerHTML;
let showTime = false;
let remainingTime = getRemainingTime();
let purchase = getPurchasedDate();

function view() {
	return m(".container", [
		m(".barcode", [m.trust(b)]),
		m(".flashpass", {onclick: () => {document.body.requestFullscreen();}, style: {background: `url(./assets/img/${word[0]}.gif)`}}, showTime ? getTimeString() : word[1].toUpperCase()),
		m(".countdown", [
			m(".countdown-days", [m("div", "Days"), m("div", remainingTime[0] > 0 ? remainingTime[0] : " ")]),
			m(".countdown-hours", [m("div", "Hours"), m("div", remainingTime[1] > 0 ? remainingTime[1] : " ")]),
			m(".countdown-minutes", [m("div", "Minutes"), m("div", remainingTime[2])]),
			m(".countdown-seconds", [m("div", "Seconds"), m("div", remainingTime[3])]),
		]),
		m(".keyvalue-container", [
			m(".keyvalue .keyvalue-big", "FirstDay-Adult-Greater Manchester"),
			m(".keyvalue", [m("span", "Provider"), m("span", "First Bus Greater Manchester")]),
			m(".keyvalue", [m("span", "Purchased"), m("span", purchase)]),
			m(".keyvalue", [m("span", "Passenger"), m("span", "Otto Normalvenbraucher")]),
		])
	]);
}

setInterval(() => {
	b = barcode().outerHTML;
}, 5000)

setInterval(() => {
	showTime = !showTime;
}, 2000)

setInterval(() => {
	remainingTime = getRemainingTime();
	m.redraw();
}, 1000);

m.mount(root, { view: view });
root.addEventListener("onclick", () => {
	root.requestFullscreen();
});


function getTimeString() {
	let d = new Date();
	return `${d.getHours().toString(10).padStart(2, '0')}:${d.getMinutes().toString(10).padStart(2, '0')}`;
}

function getPurchasedDate() {
	let d = new Date();
	const dayOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
	const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

	d.setHours(d.getHours()-2);
	d.setMinutes(Math.floor(Math.random()*60));

	return `${dayOfWeek[d.getDay()]} ${d.getDate()} ${month[d.getMonth()]} at ${d.getHours().toString(10).padStart(2, '0')}:${d.getMinutes().toString(10).padStart(2, '0')}`;
}

function getRemainingTime() {
	let ret = [];
	let d = new Date();
	let d2 = new Date();

	if (d.getHours() > 4) {
		d2.setDate(d.getDate()+1);
	}
	d2.setHours(3);
	d2.setMinutes(59);
	d2.setSeconds(0);
	d2.setMilliseconds(0);

	let diff = d2 - d;

	ret.push(Math.floor(diff / 1000 / 60 / (60 * 24)));
	diff -= ret[0] * 1000 * 60 * 60 * 60 * 24;
	ret.push(Math.floor(diff / 1000 / 60 / 60));
	diff -= ret[1] * 1000 * 60 * 60;
	ret.push(Math.floor(diff / 1000 / 60));
	diff -= ret[2] * 1000 * 60;
	ret.push(Math.floor(diff / 1000));

	return ret;
}
